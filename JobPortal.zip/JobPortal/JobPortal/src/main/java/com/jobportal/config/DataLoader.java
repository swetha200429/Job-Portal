package com.jobportal.config;

import com.jobportal.model.Job;
import com.jobportal.model.Role;
import com.jobportal.model.User;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    private final JobRepository jobRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public DataLoader(JobRepository jobRepository, UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.jobRepository = jobRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        // Only load if jobs don't already exist
        if (jobRepository.count() == 0) {
            
            // 1. Create a dummy employer account to assign the jobs to
            User employer = userRepository.findByUsername("tech_corp").orElseGet(() -> {
                User newEmployer = new User();
                newEmployer.setUsername("tech_corp");
                newEmployer.setPassword(passwordEncoder.encode("password123"));
                newEmployer.setEmail("hr@techcorp.com");
                newEmployer.setRole(Role.ROLE_EMPLOYER);
                return userRepository.save(newEmployer);
            });

            // 2. Insert Job 1: Java Developer
            Job job1 = new Job();
            job1.setTitle("Java Developer");
            job1.setLocation("Chennai");
            job1.setSkills("Java, Spring Boot");
            job1.setSalary(600000.0); // 6 LPA (Lakhs Per Annum)
            job1.setDescription("Looking for a skilled Java Developer with experience in Spring Boot to build scalable enterprise applications.");
            job1.setExperience(2); // Example experience required
            job1.setEmployer(employer);
            jobRepository.save(job1);

            // 3. Insert Job 2: Frontend Developer
            Job job2 = new Job();
            job2.setTitle("Frontend Developer");
            job2.setLocation("Chennai");
            job2.setSkills("HTML, CSS, JavaScript");
            job2.setSalary(400000.0); // 4 LPA
            job2.setDescription("We are seeking a creative Frontend Developer proficient in building responsive and dynamic user interfaces.");
            job2.setExperience(1);
            job2.setEmployer(employer);
            jobRepository.save(job2);

            // 4. Insert Job 3: Python Developer
            Job job3 = new Job();
            job3.setTitle("Python Developer");
            job3.setLocation("Bangalore");
            job3.setSkills("Python, Django");
            job3.setSalary(500000.0); // 5 LPA
            job3.setDescription("Join our dynamic team as a Python Developer. Must have solid experience in Django framework and REST APIs.");
            job3.setExperience(3);
            job3.setEmployer(employer);
            jobRepository.save(job3);
            
            System.out.println("========== Sample Jobs Loaded Successfully! ==========");
        }
    }
}

package com.jobportal.service;

import com.jobportal.model.Application;
import com.jobportal.model.ApplicationStatus;
import com.jobportal.model.Job;
import com.jobportal.model.User;
import com.jobportal.repository.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApplicationService {

    private final ApplicationRepository applicationRepository;

    @Autowired
    public ApplicationService(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    public void applyForJob(Job job, User user, String resumePath) {
        if (applicationRepository.existsByJobAndUser(job, user)) {
            throw new RuntimeException("Already Applied");
        }
        Application app = new Application();
        app.setJob(job);
        app.setUser(user);
        app.setResumePath(resumePath);
        app.setStatus(ApplicationStatus.APPLIED);
        applicationRepository.save(app);
    }

    public List<Application> getApplicationsByUser(User user) {
        return applicationRepository.findByUserOrderByAppliedOnDesc(user);
    }

    public List<Application> getApplicationsByJob(Job job) {
        return applicationRepository.findByJobOrderByAppliedOnDesc(job);
    }

    public Application getApplicationById(Long id) {
        return applicationRepository.findById(id).orElseThrow(() -> new RuntimeException("Application not found"));
    }

    public void updateApplicationStatus(Long id, ApplicationStatus status) {
        Application app = getApplicationById(id);
        app.setStatus(status);
        applicationRepository.save(app);
    }
}

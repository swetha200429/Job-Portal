package com.jobportal.repository;

import com.jobportal.model.Job;
import com.jobportal.model.User;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<Job, Long> {
    List<Job> findByEmployer(User employer);

    @Query("SELECT j FROM Job j WHERE " +
           "(:location IS NULL OR :location = '' OR LOWER(j.location) LIKE LOWER(CONCAT('%', :location, '%'))) AND " +
           "(:skills IS NULL OR :skills = '' OR LOWER(j.skills) LIKE LOWER(CONCAT('%', :skills, '%'))) AND " +
           "(:minSalary IS NULL OR j.salary >= :minSalary) AND " +
           "(:experience IS NULL OR j.experience <= :experience)")
    List<Job> searchJobs(@Param("location") String location,
                         @Param("skills") String skills,
                         @Param("minSalary") Double minSalary,
                         @Param("experience") Integer experience,
                         Sort sort);
}

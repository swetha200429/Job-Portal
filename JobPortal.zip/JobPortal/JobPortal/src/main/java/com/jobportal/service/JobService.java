package com.jobportal.service;

import com.jobportal.model.Job;
import com.jobportal.model.User;
import com.jobportal.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JobService {

    private final JobRepository jobRepository;

    @Autowired
    public JobService(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    public void saveJob(Job job) {
        jobRepository.save(job);
    }

    public List<Job> findAllJobs() {
        return jobRepository.findAll(Sort.by(Sort.Direction.DESC, "postedOn"));
    }

    public Job findJobById(Long id) {
        return jobRepository.findById(id).orElseThrow(() -> new RuntimeException("Job not found"));
    }

    public List<Job> findJobsByEmployer(User employer) {
        return jobRepository.findByEmployer(employer);
    }

    public void deleteJob(Long id) {
        jobRepository.deleteById(id);
    }

    public List<Job> searchJobs(String location, String skills, Double minSalary, Integer maxExperience, String sortField) {
        Sort sort = Sort.by(Sort.Direction.DESC, "postedOn");
        if (sortField != null && !sortField.isEmpty()) {
            sort = Sort.by(Sort.Direction.DESC, sortField);
        }
        return jobRepository.searchJobs(location, skills, minSalary, maxExperience, sort);
    }
}

package com.jobportal.controller;

import com.jobportal.model.Application;
import com.jobportal.model.ApplicationStatus;
import com.jobportal.model.Job;
import com.jobportal.model.Role;
import com.jobportal.service.ApplicationService;
import com.jobportal.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class DashboardController {

    private final JobService jobService;
    private final ApplicationService applicationService;

    @Autowired
    public DashboardController(JobService jobService, ApplicationService applicationService) {
        this.jobService = jobService;
        this.applicationService = applicationService;
    }

    @GetMapping("/")
    public String home(@RequestParam(required = false) String location,
                       @RequestParam(required = false) String skills,
                       @RequestParam(required = false) Double minSalary,
                       @RequestParam(required = false) Integer maxExperience,
                       @RequestParam(required = false) String sortField,
                       Model model) {
        List<Job> jobs = jobService.searchJobs(location, skills, minSalary, maxExperience, sortField);
        model.addAttribute("jobs", jobs);
        return "index";
    }

    @PostMapping("/apply")
    public String quickApply(@RequestParam("jobId") Long jobId, 
                             @AuthenticationPrincipal com.jobportal.security.CustomUserDetails userDetails,
                             RedirectAttributes redirectAttributes) {
        if (userDetails == null) {
            return "redirect:/login";
        }
        if (userDetails.getUser().getRole() != com.jobportal.model.Role.ROLE_STUDENT) {
            redirectAttributes.addFlashAttribute("errorMsg", "Only students can apply for jobs.");
            return "redirect:/";
        }

        try {
            Job job = jobService.findJobById(jobId);
            applicationService.applyForJob(job, userDetails.getUser(), null);
            redirectAttributes.addFlashAttribute("successMsg", "Successfully applied for " + job.getTitle() + "!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMsg", e.getMessage());
        }
        return "redirect:/";
    }

    @GetMapping("/employer/dashboard")
    public String employerDashboard(@AuthenticationPrincipal com.jobportal.security.CustomUserDetails userDetails, Model model) {
        if (userDetails.getUser().getRole() != Role.ROLE_EMPLOYER) {
            return "redirect:/";
        }
        List<Job> jobs = jobService.findJobsByEmployer(userDetails.getUser());
        model.addAttribute("jobs", jobs);
        return "employer-dashboard";
    }

    @GetMapping("/employer/job/{id}/applications")
    public String viewApplications(@PathVariable Long id, @AuthenticationPrincipal com.jobportal.security.CustomUserDetails userDetails, Model model) {
        Job job = jobService.findJobById(id);
        if (!job.getEmployer().getId().equals(userDetails.getUser().getId())) {
            return "redirect:/employer/dashboard";
        }
        List<Application> applications = applicationService.getApplicationsByJob(job);
        model.addAttribute("job", job);
        model.addAttribute("applications", applications);
        return "job-applications";
    }

    @PostMapping("/employer/application/{id}/status")
    public String updateApplicationStatus(@PathVariable Long id, @RequestParam ApplicationStatus status, RedirectAttributes redirectAttributes) {
        Application app = applicationService.getApplicationById(id);
        applicationService.updateApplicationStatus(id, status);
        redirectAttributes.addFlashAttribute("successMsg", "Application status updated.");
        return "redirect:/employer/job/" + app.getJob().getId() + "/applications";
    }

    @GetMapping("/student/dashboard")
    public String studentDashboard(@AuthenticationPrincipal com.jobportal.security.CustomUserDetails userDetails, Model model) {
        if (userDetails.getUser().getRole() != Role.ROLE_STUDENT) {
            return "redirect:/";
        }
        List<Application> applications = applicationService.getApplicationsByUser(userDetails.getUser());
        model.addAttribute("applications", applications);
        return "student-dashboard";
    }

    @GetMapping("/my-applications")
    public String myApplications(@AuthenticationPrincipal com.jobportal.security.CustomUserDetails userDetails, Model model) {
        if (userDetails == null || userDetails.getUser().getRole() != Role.ROLE_STUDENT) {
            return "redirect:/login";
        }
        List<Application> applications = applicationService.getApplicationsByUser(userDetails.getUser());
        model.addAttribute("applications", applications);
        return "my-applications";
    }
}

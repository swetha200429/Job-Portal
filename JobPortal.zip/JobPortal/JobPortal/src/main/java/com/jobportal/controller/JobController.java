package com.jobportal.controller;

import com.jobportal.model.*;
import com.jobportal.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/jobs")
public class JobController {

    private final JobService jobService;
    private final ApplicationService applicationService;
    private final FileStorageService fileStorageService;

    @Autowired
    public JobController(JobService jobService, ApplicationService applicationService, FileStorageService fileStorageService) {
        this.jobService = jobService;
        this.applicationService = applicationService;
        this.fileStorageService = fileStorageService;
    }

    @GetMapping("/{id}")
    public String viewJob(@PathVariable Long id, Model model) {
        Job job = jobService.findJobById(id);
        model.addAttribute("job", job);
        return "job-details";
    }

    @PostMapping("/{id}/apply")
    public String applyForJob(@PathVariable Long id, 
                              @RequestParam("resume") MultipartFile resume, 
                              @AuthenticationPrincipal com.jobportal.security.CustomUserDetails userDetails,
                              RedirectAttributes redirectAttributes) {
        if (userDetails.getUser().getRole() != Role.ROLE_STUDENT) {
            redirectAttributes.addFlashAttribute("errorMsg", "Only students can apply for jobs.");
            return "redirect:/jobs/" + id;
        }

        try {
            Job job = jobService.findJobById(id);
            String resumePath = fileStorageService.storeFile(resume);
            applicationService.applyForJob(job, userDetails.getUser(), resumePath);
            redirectAttributes.addFlashAttribute("successMsg", "Successfully applied for the job!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMsg", e.getMessage());
        }
        return "redirect:/jobs/" + id;
    }

    @GetMapping("/create")
    public String showCreateJobForm(Model model, @AuthenticationPrincipal com.jobportal.security.CustomUserDetails userDetails) {
        if (userDetails.getUser().getRole() != Role.ROLE_EMPLOYER) {
            return "redirect:/";
        }
        model.addAttribute("job", new Job());
        return "create-job";
    }

    @PostMapping("/create")
    public String createJob(@ModelAttribute Job job, @AuthenticationPrincipal com.jobportal.security.CustomUserDetails userDetails, RedirectAttributes redirectAttributes) {
        if (userDetails.getUser().getRole() != Role.ROLE_EMPLOYER) {
            return "redirect:/";
        }
        job.setEmployer(userDetails.getUser());
        jobService.saveJob(job);
        redirectAttributes.addFlashAttribute("successMsg", "Job posted successfully!");
        return "redirect:/employer/dashboard";
    }
}
